# Spin Together — 9-person live wheel

Everyone joins one shared room and can spin. Spins, winners, room members, and entries synchronize across connected devices.

## Deploy to Render (no coding required)

1. Upload the entire project to a new GitHub repository (keep `server.js`, `package.json`, `render.yaml`, and `public/index.html` in their existing paths).
2. Go to https://dashboard.render.com/ and choose **New > Blueprint**.
3. Connect your GitHub repository and deploy the service described by `render.yaml`.
4. Open the Render URL. Enter your name and a room code (or keep the suggested code).
5. Click **Copy invitation link** and share it with the other 8 people.
6. Every participant enters their own name, then can click **SPIN THE WHEEL**. The first spin request wins; simultaneous attempts are blocked.

**Note:** The free Render service can sleep when inactive. The first connection can take a little longer. Participant lists, wheel entries, and history are in server memory and reset when the server restarts or redeploys. Room codes are not passwords; anyone who has the room code can join up to the 9-person limit. Use a unique private code and do not use this for high-stakes draws.

## Local test

Install Node.js 20+, then run:

```bash
npm install
npm start
```

Open http://localhost:3000 in two browser tabs, and join both using the same room code.

## How it works

- Node.js server with WebSocket communication (`ws`)
- Cryptographically random selection on the server (`crypto.randomInt`)
- Every spin is locked server-side and broadcast to all connected participants
- Shared room supports up to 9 concurrently connected participants
- Results history includes winning entry and who initiated the spin
- Entry editor supports 2–60 entries; it does not have to match the number of connected people
